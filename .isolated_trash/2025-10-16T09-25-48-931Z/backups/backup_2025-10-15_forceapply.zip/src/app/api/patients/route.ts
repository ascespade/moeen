export { GET, POST } from "../../../../temp_complex/api/patients/route";
