export default function DealsKanbanPage() {
  return (
    <main className="container-app py-8">
      <h1 className="text-brand mb-4 text-2xl font-bold">
        لوحة الصفقات (Kanban)
      </h1>
      <div className="border-brand h-96 rounded-xl border bg-white p-4 dark:bg-gray-900">
        Kanban Placeholder
      </div>
    </main>
  );
}
