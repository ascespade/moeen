declare module "@supabase/supabase-js";
declare module "@supabase/ssr";
declare module "socket.io";
declare module "pg";
declare module "nodemailer";
