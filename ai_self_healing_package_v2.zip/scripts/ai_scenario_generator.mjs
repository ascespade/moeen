import fs from 'fs';
const diff = fs.existsSync('./diff_map.json') ? JSON.parse(fs.readFileSync('./diff_map.json','utf8')) : { modules: [] };
fs.mkdirSync('./tests/generated', { recursive: true });
for (const mod of diff.modules || []) {
  const file = `./tests/generated/${mod}.spec.ts`;
  const content = `// AUTO-GENERATED placeholder test for ${mod}\nimport { test, expect } from '@playwright/test';\n test('placeholder for ${mod}', async ({ page }) => { expect(true).toBe(true); });`;
  fs.writeFileSync(file, content);
  console.log('Generated placeholder test for', mod);
}
