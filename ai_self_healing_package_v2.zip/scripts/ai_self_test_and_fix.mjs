/*
AI Self-Healing Orchestrator v2
- Skips execution if triggered by ai-bot actor to avoid loops
- Runs diff analysis, generates tests, runs targeted tests, and uses Cursor via cursor_invoke.mjs
*/

import fs from 'fs';
import { execSync } from 'child_process';

const GITHUB_ACTOR = process.env.GITHUB_ACTOR || process.env.ACTOR || '';
if (GITHUB_ACTOR === 'ai-bot') {
  console.log('Triggered by ai-bot actor - skipping orchestration to avoid loop.');
  process.exit(0);
}

function run(cmd) {
  console.log('> ' + cmd);
  try { execSync(cmd, { stdio: 'inherit' }); } catch(e) { throw e; }
}

async function main() {
  console.log('AI Self-Healing Orchestrator v2 start');

  // 1) diff analysis
  try { run('node scripts/ai_diff_analyzer.mjs'); } catch(e){ console.error('diff error', e); }

  const diff = fs.existsSync('./diff_map.json') ? JSON.parse(fs.readFileSync('./diff_map.json','utf8')) : { modules: [] };
  if (!diff.modules || diff.modules.length === 0) {
    console.log('No impacted modules, running quick full check');
    try { run('npx supawright test --full --ci'); } catch(e){ console.log('full check failed'); process.exit(1); }
    process.exit(0);
  }

  // 2) generate tests
  try { run('node scripts/ai_scenario_generator.mjs'); } catch(e){ console.error('scenario generation failed', e); }

  // 3) run targeted tests
  try {
    run('npx playwright test tests/generated --reporter=list --workers=4');
  } catch (e) {
    console.error('Targeted tests failed — attempt quick auto-fixes and escalate to Cursor');
    try { run('npx eslint --fix'); run('npx prettier --write .'); } catch(err){ console.error('auto-fix tools error', err); }

    # re-run tests
    try { run('npx playwright test tests/generated --reporter=list --workers=2'); } catch(err) {
      console.error('Tests still failing after auto-fixes. Invoking Cursor agent to repair.');
      // Prepare instructions for Cursor
      const instr = JSON.stringify({ action: 'repair', diff });
      // Call cursor_invoke with env variables (CURSOR_API_KEY should be set in Actions)
      try { run(`node scripts/cursor_invoke.mjs`); } catch(cierr){ console.error('Cursor invoke failed', cierr); process.exit(1); }
      // After invocation, exit non-zero to mark workflow failed (Assistant workflow will catch and try to repair)
      process.exit(1);
    }
  }

  // 4) integration
  try { run('npx supawright test --full --ci'); } catch(e){ console.error('supawright full check failed', e); process.exit(1); }

  // If reached here success
  console.log('AI Self-Healing Orchestrator v2 completed successfully');
  process.exit(0);
}

main().catch(e=>{ console.error('fatal', e); process.exit(1); });
