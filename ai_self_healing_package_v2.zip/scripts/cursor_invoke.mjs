/**
 * Simple wrapper to invoke Cursor Background Agents API to run instructions on the repo.
 * Expects:
 *  - CURSOR_API_KEY env
 *  - REPO env (owner/repo)
 *  - BRANCH env (branch to run against)
 *  - INSTRUCTIONS env (instructions string)
 *
 * This posts a request to Cursor API and prints the response. Adapt endpoint if needed.
 */
import fetch from 'node-fetch';

const CURSOR_API = 'https://api.cursor.com/background-agents';
const key = process.env.CURSOR_API_KEY;
const repo = process.env.REPO || process.env.GITHUB_REPOSITORY;
const branch = process.env.BRANCH || process.env.GITHUB_REF_NAME || 'main';
const instructions = process.env.INSTRUCTIONS || 'Run self-healing tasks';

if (!key) {
  console.error('CURSOR_API_KEY is required');
  process.exit(2);
}

const body = {
  repo,
  branch,
  name: 'ai-self-heal-invoke-' + Date.now(),
  instructions,
  max_runtime_minutes: 60
};

console.log('Invoking Cursor API for', repo, 'branch', branch);

fetch(CURSOR_API, {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer ' + key,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(body)
}).then(res=>res.json()).then(j=>{
  console.log('Cursor response:', JSON.stringify(j, null, 2));
}).catch(err=>{
  console.error('Cursor API error:', err);
  process.exit(3);
});
