AI Self-Healing CI — Package v2

This package contains two Github Workflows and supporting scripts to run a Cursor-backed
AI Self-Healing system. The two workflows are:

1) Ultimate CI Self-Healing Agent (ultimate-self-heal.yml)
   - triggers: push (any actor except ai-bot), pull_request, schedule every 2 hours, workflow_dispatch
   - runs ai_self_test_and_fix.mjs which invokes cursor agent as needed
   - if fails, triggers the CI Assistant workflow (below) via workflow_run event

2) CI Assistant - Self-Healing Error Resolver (ci-assistant.yml)
   - triggers when Ultimate workflow fails (workflow_run of ultimate-self-heal with conclusion: failure)
   - always runs and attempts to fix only the failing workflow file using Cursor API
   - commits fixes to ai-workflow-fixes branch and opens PR

Secrets expected (add to GitHub repo Secrets):
- CURSOR_API_KEY
- GITHUB_TOKEN (actions default token ok for basic ops)
- OPENAI_API_KEY (optional for OpenAI provider)

Usage:
- Add this package to your repo, customize scripts as needed, set secrets, then push.
